<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class currancylocal extends Model
{
    protected $fillable = ['amount'];
}
