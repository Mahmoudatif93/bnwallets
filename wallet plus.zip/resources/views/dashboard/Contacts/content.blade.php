



<div id="send_email-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-body">
							<div class="text-center mt-2 mb-4">
								<a class="text-success"><span>
                              
                                <label for="editor1">{{$content}}</label>
										
									</span>
								</a>
							</div>

						
                            
						</div>
					</div>
				</div>
			</div>