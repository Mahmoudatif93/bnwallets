<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class currancynational extends Model
{
    protected $fillable = ['amount'];
}
